<html>
<head>
<title>Sign Up</title>
<meta http-equiv="refresh" content="0;url=https://bit.ly/4gK4Soz">


<!--<meta http-equiv="refresh" content="0;url=https://ryzvxm.com/pl?o=4fec3af54e6d942a1c86bc336a1a7199:2bb382dd58d3ecf1da291b9528c5c9eb&v=bigfight">-->