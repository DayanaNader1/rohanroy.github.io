<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>MMS Viral Leaked Videos Online</title>
<meta name="description" content="Watch International Friendly 2024 Live Stream On Any Device, Anywhere For Free">
<meta name="keywords" content=" International Friendly 2024 Live">
<meta name="author" content="Em2Sports">
<link href="img/icon.png" rel="icon" type="image/ico">
<link href="img/icon.png" rel="icon" type="image/png">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">

<link href="css/style.css" rel="stylesheet">
<style>
    .glow-icon {
        width: 30px;
        animation: glowing 2s infinite;
    }

    @keyframes glowing {
        0% {
            opacity: 1;
        }
        50% {
            opacity: 0.5;
            transform: scale(1.1);
        }
        100% {
            opacity: 1;
        }
    }
</style>

</head>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark top_menu" style="padding-left: 10px;padding-right: 10px;">
<div class="container mobile_header">
<a class="logo navbar-brand" href="https://bit.ly/4gK4Soz">MMS Viral</a>

<ul class="nav justify-content-end">
<li class="dropdown">
              <a href="#" class="signin_btn" role="button" aria-expanded="true">
                  <i class="fa fa-user"></i> Login | 
              </a>
			  <a class="affiliate" href="https://bit.ly/4gK4Soz">Register</a>
          </li>
</ul>
</div>
</nav>
<div class="container">
<div class="header">
     <br>
        <h2 class="text-center"><b style="color: White;">Watch Viral Leaked Videos Online Free</h2>
	  <br>
	  
	  
	  <b style="color: White;">
<!-------Start-------->
					<div class="ads">
					  <center>
					    <script type="text/javascript">
	atOptions = {
		'key' : 'bd432bbdcd4897e43c0d8cf4854b18bc',
		'format' : 'iframe',
		'height' : 90,
		'width' : 728,
		'params' : {}
	};
</script>
<script type="text/javascript" src="//www.topcreativeformat.com/bd432bbdcd4897e43c0d8cf4854b18bc/invoke.js"></script>
					  </center>
					</div>
<!-------ends-------->
</b>

</div>



<div class="video_section" id="video">
<img class="img img-fluid" src="https://i.imgur.com/N0KXjb8.jpg">
<div class="video_player videoPlayerBtn">
<span id="play" class="play-btn-border ease"><i class="fa fa-play-circle headline-round ease" aria-hidden="true"></i></span>
</div>
<div class="text-center videoLoading" style="display:none">
<span class="spinner loading"></span>
</div>
<div class="controls">
<div class="controlContent">
<div id="leftControls">
<i class="fa fa-play controlBtn videoPlayerBtn" aria-hidden="true"></i> &nbsp;&nbsp;
<i class="fa fa-volume-up controlBtn" aria-hidden="true"></i>
</div>
<div id="rightControls">
<span class="live-badge__icon"></span> LIVE &nbsp;&nbsp;
<i class="fa fa-cog"></i> &nbsp;&nbsp;
<i class="fa fa-arrows icon-size-fullscreen"></i>
</div>
</div>
</div>
</div>
<br />
<div class="text-center">
<a class="btn btn-outline affiliate" href="https://bit.ly/4gK4Soz">Watch Now</a>
<a class="btn btn-outline affiliate" href="https://bit.ly/4gK4Soz">DOWNLOAD FREE</a>
</div><br>



</center>
<h1 class="text-center" style="font-weight: 400; font-size: 1.6rem;">Watch Viral Leaked Videos Online For Free</h1>


<center> <div class="col-md-7">
			<div class="device-features__content text-left">
			<div style="text-align: center; color: rgba(248, 251, 255, 0.8); padding: 20px; font-size: 1.1rem; line-height: 1.5;">
  Watch Viral Leaked Videos Online for FREE, On Social Media X Twitter & Telegram channel, TV Coverage, Replays, Highlights from Anywhere at Anytime. Optimized for PC, Mac, iPad, iPhone, Android, PS4, Xbox One, and Smart TVs.
</div>


 <!--ads start here-->
 
<center>
  <script type="text/javascript">
	atOptions = {
		'key' : 'e50d5f76aa9b9b27541b85ce3cef5640',
		'format' : 'iframe',
		'height' : 250,
		'width' : 300,
		'params' : {}
	};
</script>
<script type="text/javascript" src="//www.topcreativeformat.com/e50d5f76aa9b9b27541b85ce3cef5640/invoke.js"></script>
</center>

<!--ads end here-->



				<center> <div class="device-features__brands">
				<div class="device-features__brands">
    <img class="img-fluid glow-icon" src="img/devices_pc.png" alt="All Devices">
    <img class="img-fluid glow-icon" src="img/apple_pc.png" alt="iOS">
    <img class="img-fluid glow-icon" src="img/android_pc.png" alt="Android">
    <img class="img-fluid glow-icon" src="img/chromecast_pc.png" alt="Chromecast">
</div>
				</div> </center> </center>

<center> <a href="https://bit.ly/4gK4Soz" class="btn btn-md btn-outline affiliate">Create Free Account</a> </center>

<!--Commnet Section Start!-->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $(document).ready(function() {
    // Function to toggle comments visibility
    function toggleComments() {
      $('#commentContent').toggle();
    }

    // Event handler for clicking the comment button
    $('.comment-button').on('click', function() {
      toggleComments();
    });

    // Function to submit a new comment
    function submitComment(commentText) {
      var commentHtml = `
        <div class="comment-row">
          <img class="profile-img" src="https://i.imgur.com/anonymous-avatar.jpg" alt="">
          <div class="user-wrapper">
            <div class="username">Anonymous</div>
            <div class="clear"></div>
            <div class="user-comment">${commentText}</div>
            <div class="like-reply time">
              <a href="#" data-toggle="modal" data-target="#player-modal">Reply</a> · 
              <a href="#" data-toggle="modal" data-target="#player-modal" class="">
                <i><img src="https://i.imgur.com/JFj81vl.png" width="15" height="15"></i> 0</a> · 
              <a href="#" data-toggle="modal" data-target="#player-modal">Like</a> · Just now</div>
          </div>
          <div class="clear"></div>
        </div>
      `;
      $('#commentContent').prepend(commentHtml);
    }

    // Event handler for submitting a new comment on Enter key
    $('.comment-input').on('keydown', function(event) {
      if (event.key === 'Enter') {
        var commentText = $(this).val();
        if (commentText.trim() !== '') {
          submitComment(commentText);
          $(this).val('');
          event.preventDefault();
        }
      }
    });

    // Event handler for clicking the "Comment" link
    $('.comment-button').on('click', function() {
      var commentText = $('.comment-input').val();
      if (commentText.trim() !== '') {
        submitComment(commentText);
        $('.comment-input').val('');
      }
    });
  });
</script>


<div class="row-mobile">
<div style="padding: 20px; background: white; margin-top: 50px; overflow: hidden; font-family: sans-serif!important;">
<div class="col-md-12">
<div class="row-mobile">
<div class="comment-wrapper">
<div class="comments-title">10 Comments</div>

 <div class="comment-area">
    <input class="comment-input" placeholder="Write a comment..." type="text">
    <div class="commbt">
      <a href="#" class="js-trigger comment-button x-domain" onclick="toggleComments()">Comment</a>
    </div>
  </div>
</div>

<div id="commentContent" style="display: none;">

</div>
<div class="comment-row">
<img class="profile-img" src="https://i.imgur.com/Wx6NVdV.png" alt="">
<div class="user-wrapper">
<div class="username">Terry Barnes</div>
<div class="clear"></div>
<div class="user-comment">Thank you very much - was lookin for for a veery long time</div>
<div class="like-reply time">
<a href="#" data-toggle="modal" data-target="#player-modal">Reply</a> · <a href="#" data-toggle="modal" data-target="#player-modal" class=""><i><img src="https://i.imgur.com/JFj81vl.png" width="15" height="15"></i> 52</a> · <a href="#" data-toggle="modal" data-target="#player-modal">Like</a> · 12 minute ago</div>
</div>
<div class="clear"></div>
</div>
<div class="comment-row">
<img class="profile-img" src="https://i.imgur.com/rChvxTY.png" alt="">
<div class="user-wrapper">
<div class="username">Taylor Mackenzie</div>
<div class="clear"></div>
<div class="user-comment">OMG amazing! I love this site</div>
<div class="like-reply time">
 <a href="#" data-toggle="modal" data-target="#player-modal">Reply</a> · <a href="#" data-toggle="modal" data-target="#player-modal" class=""><i><img src="https://i.imgur.com/JFj81vl.png" width="15" height="15"></i> 118</a> · <a href="#" data-toggle="modal" data-target="#player-modal">Like</a> · 15 minute ago</div>
</div>
<div class="clear"></div>
</div>
<div class="comment-row">
<img class="profile-img" src="https://i.imgur.com/X6flv3p.png" alt="">
<div class="user-wrapper">
<div class="username">Joseph J. Trumbull</div>
<div class="clear"></div>
<div class="user-comment">Great selection and quality is better than TV Cable, no kidding.</div>
<div class="like-reply time">
<a href="#" data-toggle="modal" data-target="#player-modal">Reply</a> · <a href="#" data-toggle="modal" data-target="#player-modal" class=""><i><img src="https://i.imgur.com/JFj81vl.png" width="15" height="15"></i> 35</a> · <a href="#" data-toggle="modal" data-target="#player-modal">Like</a> · 15 minute ago</div>
</div>
<div class="clear"></div>
</div>
<div class="comment-row">
<img class="profile-img" src="https://i.imgur.com/lz7BAqo.png" alt="">
<div class="user-wrapper">
<div class="username">Pastor Shahuano</div>
<div class="clear"></div>
<div class="user-comment">Sign up was really easy. In 2 minutes I was hooked up</div>
<div class="like-reply time">
<a href="#" data-toggle="modal" data-target="#player-modal">Reply</a> · <a href="#" data-toggle="modal" data-target="#player-modal" class=""><i><img src="https://i.imgur.com/JFj81vl.png" width="15" height="15"></i> 178</a> · <a href="#" data-toggle="modal" data-target="#player-modal">Like</a> · 17 minute ago</div>
</div>
<div class="clear"></div>
</div>
<div class="comment-row" id="fbFeedbackContent">
<img class="profile-img" src="https://i.imgur.com/j8DF2ao.png" alt="">
<div class="user-wrapper">
<div class="username">Eric Mn</div>
<div class="clear"></div>
<div class="user-comment">Yes this really works! Just got my free account</div>
<div class="like-reply time">
 <a href="#" data-toggle="modal" data-target="#player-modal">Reply</a> · <a href="#" data-toggle="modal" data-target="#player-modal" class=""><i><img src="https://i.imgur.com/JFj81vl.png" width="15" height="15"></i> 48</a> · <a href="#" data-toggle="modal" data-target="#player-modal">Like</a> · 30 minute ago</div>
</div>
<div class="clear"></div>
</div>
<div class="comment-row">
<img class="profile-img" src="https://i.imgur.com/PZV8zzG.png" alt="">
<div class="user-wrapper">
<div class="username">Samuel H. Beck</div>
<div class="clear"></div>
<div class="user-comment">Live streaming work on my telly , its Cool !!</div>
<div class="like-reply time">
<a href="#" data-toggle="modal" data-target="#player-modal">Reply</a> · <a href="#" data-toggle="modal" data-target="#player-modal" class=""><i><img src="https://i.imgur.com/JFj81vl.png" width="15" height="15"></i> 52</a> · <a href="#" data-toggle="modal" data-target="#player-modal">Like</a> · 45 minute ago</div>
</div>
<div class="clear"></div>
</div>
<div class="comment-row">
<img class="profile-img" src="https://i.imgur.com/QUYPOTZ.png" alt="">
<div class="user-wrapper">
<div class="username">Laura Velez Garcia</div>
<div class="clear"></div>
<div class="user-comment">10/10 WEBSITE , Fantastic Library !! would recomended this to everyone.</div>
<div class="like-reply time">
<a href="#" data-toggle="modal" data-target="#player-modal">Reply</a> · <a href="#" data-toggle="modal" data-target="#player-modal" class=""><i><img src="https://i.imgur.com/JFj81vl.png" width="15" height="15"></i> 35</a> · <a href="#" data-toggle="modal" data-target="#player-modal">Like</a> · 1 hour ago</div>
</div>
<div class="clear"></div>
</div>
<div class="comment-row">
<img class="profile-img" src="https://i.imgur.com/tu2nETS.png" alt="">
<div class="user-wrapper">
<div class="username">Brenda Liggett</div>
 <div class="clear"></div>
<div class="user-comment">Excited, Happy Watching guys !!!</div>
<div class="like-reply time">
<a href="#" data-toggle="modal" data-target="#player-modal">Reply</a> · <a href="#" data-toggle="modal" data-target="#player-modal" class=""><i><img src="https://i.imgur.com/JFj81vl.png" width="15" height="15"></i> 78</a> · <a href="#" data-toggle="modal" data-target="#player-modal">Like</a> · 2 hour ago</div>
</div>
<div class="clear"></div>
</div>
<div class="comment-row sub">
<img class="profile-img" src="https://i.imgur.com/XbiDb7c.png" alt="">
<div class="user-wrapper">
<div class="username">Alfred Lendio Jr.</div>
<div class="clear"></div>
<div class="user-comment">Thanks, I'm so glad to be watching
<img src="https://i.imgur.com/delYypL.png" style="height: 13px;">
</div>
<div class="like-reply time">
<a href="#" data-toggle="modal" data-target="#player-modal">Reply</a> · <a href="#" data-toggle="modal" data-target="#player-modal" class=""><i><img src="https://i.imgur.com/JFj81vl.png" width="15" height="15"></i> 35</a> · <a href="#" data-toggle="modal" data-target="#player-modal">Like</a> · 2 hour ago</div>
</div>
<div class="clear"></div>
</div>
<div class="comment-row">
<img class="profile-img" src="https://i.imgur.com/KLmX3Ui.png" alt="">
<div class="user-wrapper">
<div class="username">Jenifer Lopez</div>
<div class="clear"></div>
<div class="user-comment">Love that so many are available in HD</div>
<div class="like-reply time">
<a href="#" data-toggle="modal" data-target="#player-modal">Reply</a> · <a href="#" data-toggle="modal" data-target="#player-modal" class=""><i><img src="https://i.imgur.com/JFj81vl.png" width="15" height="15"></i> 78</a> · <a href="#" data-toggle="modal" data-target="#player-modal">Like</a> · 2 hour ago</div>
 </div>
<div class="clear"></div>
</div>
</div>
</div>
</div>
</div>
<!--Comment Section End!-->
















<footer class="footer">
    

<br>    
<div class="container">
<div class="row">
<div class="col-md-6 col-xs-12">
<div class="copyright">Copyright @ livesportsnow.xyz | All rights reserved</div>
</div>
<div class="col-md-6 col-xs-12">
<div class="footer__links d-flex justify-content-end">
<a href="https://em2sports.com/disclaimer/" data-page='dmca' data-title="DMCA" class="info">DMCA</a>
<a href="https://em2sports.com/privacy-policy/" data-page='privacy' data-title="Privacy Policy" class="info">Privacy Policy</a>
<a href="https://em2sports.com/terms-conditions/" data-page='terms' data-title="Terms and Condition" class="info">Terms &amp; Condition</a>
</div>
</div>
</div>
</div>


</footer>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="//use.fontawesome.com/3db27005e3.js"></script>
<script type="text/javascript">
    var count = 1171;

    function tick() {
        count += Math.round(Math.random() * 50);
        $('#online').text(count); // Use # to target element by ID
        setTimeout(tick, Math.round(1000 + Math.random() * 2000));
    }
    tick();
</script>
<style type="text/css">
    #counter {
        position: fixed;
        right: 15px;
        bottom: 15px;
        padding: 7px 15px;
        background: rgba(0, 0, 0, .5);
        width: auto;
        z-index: 999;
    }
</style>
<div id="counter">
    <img src="ajax-loader.gif" style="background-repeat: no-repeat;width:43px;z-index:999;height:11px;margin-bottom:5px;"> &nbsp;&nbsp;
    <span class="counter-value" id="online"></span> <span style="color:#fff;">Users Online </span>
</div>


<div id="singin_panel">
<div class="signin__close">
<i class="fa fa-close fa-lg" aria-hidden="true"></i>
</div>
<div class="signin__holder">
<form id="signinform">
<div class="signin__default">
<h1>Sign In</h1>
<div class="signin__group">
<label for="email" class="">Email</label>
<input type="text" id="email" placeholder="Enter your email">
</div>
<div class="signin__group">
<label for="password" class="">Password</label>
<span class="label-note" id="forgotpass">Forgot Password?</span>
<input type="password" id="password" placeholder="Enter your password">
</div>
<div class="form-alert" style="display: none;">Oops! You forgot to enter an email address</div>
<button class="btn btn-outline btn-md mt-3 singin_btn" type="submit">Sign In</button>
<div class="signin__footer">
<a href="https://bit.ly/4gK4Soz" class="affiliate">Don't have an account? <span>Sign Up</span></a>
</div>
</div>
</form>
<form id="resetpassform">
<div class="signin__resetpassword" style="display: none;">
<h1>Reset Password</h1>
<p class="text-muted">Enter your email address and we'll send you a link to reset your password.</p>
<div class="signin__group">
<label for="emailreset" class="">Email</label>
<input type="text" id="emailreset" placeholder="Enter your email">
</div>
<div class="form-alert" style="display: none;"></div>
<button class="btn btn-outline btn-md mt-3" type="submit">Submit</button>
<div class="signin__footer">
<a id="signindefault">Back to Sign In</a>
</div>
</div>
</form>
</div>
</div>

<div class="modal fade" id="video_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog modal-lg" role="document">
<div class="modal-content">
<div class="modal-header modal_header_info">
<h6 class="modal-title text-center" id="exampleModalLabel">Please Sign Up to Watch Viral Leaked Videos Online FREE</h6>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
<div class="row">
<div class="col-md-6">
<div><img class="img-fluid" src="viral.webp" alt="image"></div>
<h5>Member Login</h5>
<div class="form-group">
<input type="text" class="form-control input-sm" id="userid" placeholder="username">
</div>
<div class="form-group">
<input type="password" class="form-control input-sm" id="password" placeholder="password">
</div>
<p class="msg">
</p>
<input type="button" id="modal_login_btn" class="btn btn-primary" value="Log in">
<a class="affiliate btn btn-block btn-success" href="https://bit.ly/4gK4Soz" target=""> Sign Up For Free!</a>
</div>
<div class="col-md-6">
<div class="list-group">
<div class="list-group-item modal-list">
<h6 class="list-group-item-heading"><i class="fa fa-film biru fa-fw"></i> High Quality Streaming</h6>
<p class="list-group-item-text">All of the Live Sports are available in the HD Quality or even higher!</p>
</div>
<div class="list-group-item modal-list">
<h6 class="list-group-item-heading"><i class="fa fa-youtube-play pink fa-fw"></i> Watch Without Limits</h6>
<p class="list-group-item-text">You will get access to all of your favourite Sports without any limits.</p>
</div>
<div class="list-group-item modal-list">
<h6 class="list-group-item-heading"><i class="fa fa-ban coklat fa-fw"></i> No Ads, 100% Free Advertising</h6>
<p class="list-group-item-text">Your account will always be free from all kinds of advertising.</p>
</div>
<div class="list-group-item modal-list">
<h6 class="list-group-item-heading"><i class="fa fa-tablet ijo fa-fw"></i> Watch anytime, anywhere</h6>
<p class="list-group-item-text">It works on your Mobile, TV, PC or MAC & More, wherever you are. No geo-restrictions.</p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="modal fade" id="page_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog modal-lg" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="info_page_title"></h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
</div>
<div class="modal-footer">
</div>
</div>
</div>
</div>



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="/assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<script type="text/javascript">
$(function(){
	  $('.signin_btn').on('click', function(e){
	  		e.preventDefault();
	  		$('#singin_panel').addClass('open');
	  });
	  
	  $('.signin__close').on('click', function(e){
	  	e.preventDefault();
	  	$('#singin_panel').removeClass('open');
	  });
	  
	  $('#forgotpass').on('click', function(e){
	  	e.preventDefault();
	  	$('.signin__default').hide();
		$('.signin__resetpassword').show();
	  });
	  
	  $('#signindefault').on('click', function(e) {
	  	e.preventDefault();
	  	$('.signin__default').show();
		$('.signin__resetpassword').hide();
	  });
	  $('.singin_btn').on('click', function(e) {
	  	e.preventDefault();
	  	$('.form-alert').show();
		$('#email').addClass('invalid');
	  });
	  
	  $('.login_btn').on('click', function(e){
	  	e.preventDefault();
	  	$('.login_refresh').show();
		$('.login_btn').hide();
		$('.loginError').hide();
	  	setTimeout(function(){
			$('.memberLogin').hide();
			$('.login_refresh').hide();
			$('.loginError').show();
			$('.login_btn').show();
		},2000);
	  });
	  
	  $('#modal_login_btn').on('click', function(e){
	  	e.preventDefault();
	  	str ="<span class='badge badge-info'>Please wait...</span>";
	  	$('.msg').html(str);
		$('.msg').addClass("");
	  	setTimeout(function(){
			str ="<span class='badge badge-warning'>Wrong Username or Password</span>";
	  		$('.msg').html(str);
		},2000);
	  });
	  
	
	  $('.videoPlayerBtn').on('click', function(e){
	  	e.preventDefault();
		let url=$(this).attr('data-url');
		$('.video_player').hide();
		$('.videoLoading').show();
	
		setTimeout(function(){ 
		 // window.location.href=url;
		 $('#video_modal').modal('show');
		}, 2000);
	  });
	  
	  $('#video_modal').on('hidden.bs.modal', function (e) {
	  		e.preventDefault();
	  		$('.videoLoading').hide();
			$('.video_player').show();
		});
	  
	  $('.info').on('click', function(e){
		 e.preventDefault();
		 var page = $(this).attr('data-page');
		 page = page+'.php'
		 page_title = $(this).attr('data-title');
		 //$("#page_modal").load("");
		 $('#page_modal').find('.modal-body').load(page, function(data){
		 	$('#info_page_title').text(page_title);
			$('#page_modal').modal('show');
		 });
		 //alert(page);
	  });
	  
	  $('.affiliate').on('click', function(e){
	  	e.preventDefault();
		window.location = "https://bit.ly/4gK4Soz";
	  });
	  
	  $(document).on('click', '.icon-size-fullscreen', function (e) {
		e.preventDefault();
		launchIntoFullscreen(document.getElementById("video"));
		});
		
		$(document).on('click', '.icon-size-actual', function (e) {
			e.preventDefault();
			exitFullscreen();
		});
	  
	  
  
  });
  
	  function launchIntoFullscreen(element) {
		if(element.requestFullscreen) {
			element.requestFullscreen();
		} else if(element.mozRequestFullScreen) {
			element.mozRequestFullScreen();
		} else if(element.webkitRequestFullscreen) {
			element.webkitRequestFullscreen();
		} else if(element.msRequestFullscreen) {
			element.msRequestFullscreen();
		}
		$(".icon-size-fullscreen").removeClass("icon-size-fullscreen").addClass("icon-size-actual");
	}
	function exitFullscreen() {
		if(document.exitFullscreen) {
			document.exitFullscreen();
		} else if(document.mozCancelFullScreen) {
			document.mozCancelFullScreen();
		} else if(document.webkitExitFullscreen) {
			document.webkitExitFullscreen();
		}
		$(".icon-size-actual").removeClass("icon-size-actual").addClass("icon-size-fullscreen");
	}
	$(document).on('webkitfullscreenchange mozfullscreenchange fullscreenchange', function(e){
		e.preventDefault();
		var fullScreen = document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement ? true : false;
		if ( fullScreen ) {
			$(".icon-size-fullscreen").removeClass("icon-size-fullscreen").addClass("icon-size-actual");
		} else {
			$(".icon-size-actual").removeClass("icon-size-actual").addClass("icon-size-fullscreen");
		}
	});


</script>
</div>
</body>
</html>

<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,4897823,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
